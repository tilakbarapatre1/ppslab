'''1.1.2. Area of the Rectangle
00:54





You are given a length L and breadth B and your task is to find the Area of the Rectangle.



Note:

The values of L and B are already provided using input function in uneditable mode.
Your input and output layout must match the visible sample test case.

Sample Test Cases
Test case 1
L:2	
B:3	
6⏎'''

L=int(input("L:"))
B=int(input("B:"))
area = L*B
print(area)
