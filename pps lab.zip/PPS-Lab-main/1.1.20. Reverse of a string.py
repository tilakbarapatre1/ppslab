'''Write a Python program to find the reverse of a string.



Input Format:

The input should be a string.


Output Format:

The output should be the reverse of a string.

Sample Test Cases
Test case 1
CodeTantra	
artnaTedoC⏎	
Test case 2
Programming	
gnimmargorP⏎'''

s = input()
reversed = s[::-1]

print(reversed)
