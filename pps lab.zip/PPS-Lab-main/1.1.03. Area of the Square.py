'''1.1.3. Area of the Square




You are given a side S and your task is to find the Area of the square.



Note:

The value of S is already provided using input function in uneditable mode.
Your input and output layout must match the visible sample test case.

Sample Test Cases
Test case 1
S:2	
4⏎'''


S=int(input("S:")) # Make use of the value of S read using the input function.
area = S*S
print(area)
